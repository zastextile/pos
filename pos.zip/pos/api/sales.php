<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

$user = api_user('staff');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['ok' => false, 'message' => 'Method not allowed.'], 405);
}

$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($contentLength > 1048576) {
    json_response(['ok' => false, 'message' => 'Request is too large.'], 413);
}

$csrf = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if ($csrf === '' || !hash_equals(csrf_token(), $csrf)) {
    json_response(['ok' => false, 'message' => 'Your session expired. Refresh and try again.'], 419);
}

$payload = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($payload) || !isset($payload['items']) || !is_array($payload['items'])) {
    json_response(['ok' => false, 'message' => 'Invalid sale data.'], 422);
}

if (count($payload['items']) < 1 || count($payload['items']) > 200) {
    json_response(['ok' => false, 'message' => 'Add at least one valid product.'], 422);
}

$quantities = [];
foreach ($payload['items'] as $item) {
    if (!is_array($item)) {
        continue;
    }
    $productId = filter_var($item['id'] ?? null, FILTER_VALIDATE_INT);
    $quantity = filter_var($item['quantity'] ?? null, FILTER_VALIDATE_INT);
    if (!$productId || !$quantity || $quantity < 1 || $quantity > 9999) {
        json_response(['ok' => false, 'message' => 'One or more product quantities are invalid.'], 422);
    }
    $quantities[(int) $productId] = min(9999, ($quantities[(int) $productId] ?? 0) + (int) $quantity);
}

if (!$quantities) {
    json_response(['ok' => false, 'message' => 'Add at least one valid product.'], 422);
}

$ids = array_keys($quantities);
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$productQuery = database()->prepare(
    "SELECT id, product_name, barcode, rate FROM products WHERE status = 'active' AND id IN ({$placeholders})"
);
$productQuery->execute($ids);
$products = [];
foreach ($productQuery->fetchAll() as $product) {
    $products[(int) $product['id']] = $product;
}

if (count($products) !== count($ids)) {
    json_response(['ok' => false, 'message' => 'A product is missing or inactive. Please refresh the cart.'], 409);
}

$saleItems = [];
$totalCents = 0;
foreach ($quantities as $productId => $quantity) {
    $product = $products[$productId];
    $rateCents = (int) round((float) $product['rate'] * 100);
    $lineCents = $rateCents * $quantity;
    $totalCents += $lineCents;
    $saleItems[] = [
        'product_id' => $productId,
        'product_name' => $product['product_name'],
        'barcode' => $product['barcode'],
        'rate' => number_format($rateCents / 100, 2, '.', ''),
        'quantity' => $quantity,
        'line_total' => number_format($lineCents / 100, 2, '.', ''),
    ];
}

$clean = static function (mixed $value, int $limit): ?string {
    $text = trim((string) $value);
    if ($text === '') {
        return null;
    }
    return function_exists('mb_substr') ? mb_substr($text, 0, $limit) : substr($text, 0, $limit);
};

$customerName = $clean($payload['customer_name'] ?? '', 150);
$customerContact = $clean($payload['customer_contact'] ?? '', 60);
$customerAddress = $clean($payload['customer_address'] ?? '', 500);
$now = new DateTimeImmutable('now');
$pdo = database();

try {
    $pdo->beginTransaction();
    $saleStatement = $pdo->prepare(
        "INSERT INTO sales
        (staff_id, staff_name, customer_name, customer_contact, customer_address, total_amount, status, sale_date, sale_time)
        VALUES (:staff_id, :staff_name, :customer_name, :customer_contact, :customer_address, :total_amount, 'draft', :sale_date, :sale_time)"
    );
    $saleStatement->execute([
        'staff_id' => $user['id'],
        'staff_name' => $user['name'],
        'customer_name' => $customerName,
        'customer_contact' => $customerContact,
        'customer_address' => $customerAddress,
        'total_amount' => number_format($totalCents / 100, 2, '.', ''),
        'sale_date' => $now->format('Y-m-d'),
        'sale_time' => $now->format('H:i:s'),
    ]);
    $saleId = (int) $pdo->lastInsertId();

    $itemStatement = $pdo->prepare(
        "INSERT INTO sale_items
        (sale_id, product_id, product_name, barcode, rate, quantity, line_total)
        VALUES (:sale_id, :product_id, :product_name, :barcode, :rate, :quantity, :line_total)"
    );
    foreach ($saleItems as $item) {
        $itemStatement->execute(array_merge(['sale_id' => $saleId], $item));
    }

    $pdo->commit();
    json_response([
        'ok' => true,
        'sale_id' => $saleId,
        'total' => $totalCents / 100,
        'message' => 'Sale saved successfully.',
    ], 201);
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Sale save failed: ' . $exception->getMessage());
    json_response(['ok' => false, 'message' => 'Sale could not be saved. Please try again.'], 500);
}
