(() => {
  "use strict";

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => undefined));
  }

  const app = document.getElementById("sale-app");
  if (!app) return;

  const elements = {
    scanOpen: document.getElementById("scan-open"),
    manualOpen: document.getElementById("manual-open"),
    scannerOverlay: document.getElementById("scanner-overlay"),
    scannerClose: document.getElementById("scanner-close"),
    scannerNext: document.getElementById("scanner-next"),
    scannerHelp: document.getElementById("scanner-help"),
    barcodeForm: document.getElementById("manual-barcode-form"),
    barcodeInput: document.getElementById("barcode-input"),
    cartTitle: document.getElementById("cart-title"),
    cartList: document.getElementById("cart-list"),
    cartClear: document.getElementById("cart-clear"),
    saleTotal: document.getElementById("sale-total"),
    checkoutTotal: document.getElementById("checkout-total"),
    checkoutOpen: document.getElementById("checkout-open"),
    checkoutOverlay: document.getElementById("checkout-overlay"),
    checkoutClose: document.getElementById("checkout-close"),
    saveSale: document.getElementById("save-sale"),
    customerName: document.getElementById("customer-name"),
    customerContact: document.getElementById("customer-contact"),
    customerAddress: document.getElementById("customer-address"),
    success: document.getElementById("sale-success"),
    successReference: document.getElementById("success-reference"),
    newSale: document.getElementById("new-sale"),
    toast: document.getElementById("toast"),
  };

  const storageKey = `zas-sales-cart-v1:${app.dataset.staffId}`;
  let cart = loadCart();
  let scanner = null;
  let scannerRunning = false;
  let scannerWanted = false;
  let scanLock = false;
  let toastTimer = null;
  let lastCode = "";
  let lastCodeAt = 0;

  function loadCart() {
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
      if (!Array.isArray(saved)) return [];
      return saved.filter((item) =>
        Number.isInteger(Number(item.id)) &&
        typeof item.name === "string" &&
        typeof item.barcode === "string" &&
        Number(item.rate) >= 0 &&
        Number.isInteger(Number(item.quantity)) &&
        Number(item.quantity) > 0
      ).map((item) => ({
        id: Number(item.id),
        name: item.name,
        barcode: item.barcode,
        rate: Number(item.rate),
        quantity: Math.min(9999, Number(item.quantity)),
      }));
    } catch {
      localStorage.removeItem(storageKey);
      return [];
    }
  }

  function persistCart() {
    localStorage.setItem(storageKey, JSON.stringify(cart));
  }

  function formatMoney(value) {
    return `Rs. ${new Intl.NumberFormat("en-PK", { maximumFractionDigits: 0 }).format(value)}`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;",
    })[character]);
  }

  function cartTotal() {
    return cart.reduce((total, item) => total + item.rate * item.quantity, 0);
  }

  function renderCart() {
    const total = cartTotal();
    elements.cartTitle.textContent = cart.length
      ? `${cart.length} product${cart.length === 1 ? "" : "s"}`
      : "No products yet";
    elements.cartClear.classList.toggle("hidden", cart.length === 0);
    elements.checkoutOpen.disabled = cart.length === 0;
    elements.saleTotal.textContent = formatMoney(total);
    elements.checkoutTotal.textContent = formatMoney(total);

    if (!cart.length) {
      elements.cartList.innerHTML = '<div class="empty-card"><span class="barcode-symbol">▥</span><p>Scan a product to start the sale.</p></div>';
      persistCart();
      return;
    }

    elements.cartList.innerHTML = `<div class="cart-list">${cart.map((item) => `
      <article class="cart-card" data-product-id="${item.id}">
        <div class="item-head">
          <div><h3>${escapeHtml(item.name)}</h3><p>${formatMoney(item.rate)} each</p></div>
          <strong>${formatMoney(item.rate * item.quantity)}</strong>
        </div>
        <div class="quantity-row">
          <button class="quantity-button" type="button" data-action="decrease" aria-label="Decrease ${escapeHtml(item.name)}">−</button>
          <output aria-label="${item.quantity} units">${item.quantity}</output>
          <button class="quantity-button" type="button" data-action="increase" aria-label="Increase ${escapeHtml(item.name)}">+</button>
          <button class="remove-item" type="button" data-action="remove">Remove</button>
        </div>
      </article>`).join("")}</div>`;
    persistCart();
  }

  function showToast(message, isError = false) {
    window.clearTimeout(toastTimer);
    elements.toast.textContent = message;
    elements.toast.style.background = isError ? "#8f2d34" : "#17201d";
    elements.toast.classList.remove("hidden");
    toastTimer = window.setTimeout(() => elements.toast.classList.add("hidden"), 2200);
  }

  function addProduct(product) {
    const existing = cart.find((item) => item.id === Number(product.id));
    if (existing) {
      existing.quantity = Math.min(9999, existing.quantity + 1);
    } else {
      cart.push({
        id: Number(product.id),
        name: String(product.name),
        barcode: String(product.barcode),
        rate: Number(product.rate),
        quantity: 1,
      });
    }
    renderCart();
    showToast(`${product.name} added`);
    if (navigator.vibrate) navigator.vibrate(80);
  }

  async function findProduct(barcode, fromCamera = false) {
    const code = String(barcode || "").trim();
    if (!code) {
      showToast("Enter a barcode number.", true);
      return false;
    }

    elements.scannerHelp.textContent = "Finding product…";
    try {
      const response = await fetch(`${app.dataset.productUrl}?barcode=${encodeURIComponent(code)}`, {
        headers: { Accept: "application/json" },
        credentials: "same-origin",
        cache: "no-store",
      });
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.message || "Product not found.");
      addProduct(data.product);
      elements.barcodeInput.value = "";
      elements.scannerHelp.textContent = "Product added. Scan the next barcode.";
      return true;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Product could not be found.";
      elements.scannerHelp.textContent = message;
      showToast(message, true);
      if (!fromCamera) elements.barcodeInput.focus();
      return false;
    }
  }

  async function stopCamera() {
    if (!scanner) return;
    try {
      if (scannerRunning) await scanner.stop();
    } catch {
      // The camera may already have stopped.
    }
    try { scanner.clear(); } catch { /* no-op */ }
    scanner = null;
    scannerRunning = false;
  }

  async function startCamera() {
    scannerWanted = true;
    elements.scannerNext.classList.add("hidden");
    if (typeof window.Html5Qrcode === "undefined") {
      elements.scannerHelp.textContent = "Camera scanner is unavailable. Enter the barcode manually.";
      elements.scannerNext.classList.remove("hidden");
      return;
    }
    if (scannerRunning || scanner) return;

    const formats = window.Html5QrcodeSupportedFormats;
    const config = formats ? {
      formatsToSupport: [formats.EAN_13, formats.EAN_8, formats.UPC_A, formats.UPC_E, formats.CODE_128, formats.QR_CODE],
      verbose: false,
    } : { verbose: false };
    scanner = new window.Html5Qrcode("reader", config);
    elements.scannerHelp.textContent = "Starting camera…";

    try {
      await scanner.start(
        { facingMode: "environment" },
        {
          fps: 10,
          aspectRatio: 1.777,
          qrbox: (width, height) => ({ width: Math.floor(width * .82), height: Math.min(150, Math.floor(height * .55)) }),
        },
        async (decodedText) => {
          const now = Date.now();
          if (scanLock || (decodedText === lastCode && now - lastCodeAt < 2400)) return;
          scanLock = true;
          lastCode = decodedText;
          lastCodeAt = now;
          await stopCamera();
          await findProduct(decodedText, true);
          window.setTimeout(async () => {
            scanLock = false;
            if (scannerWanted && !elements.scannerOverlay.classList.contains("hidden")) await startCamera();
          }, 800);
        },
        () => undefined
      );
      scannerRunning = true;
      elements.scannerHelp.textContent = "Point the camera at a barcode.";
    } catch {
      await stopCamera();
      elements.scannerHelp.textContent = "Camera could not start. Check permission or enter the barcode manually.";
      elements.scannerNext.classList.remove("hidden");
    }
  }

  async function openScanner(useCamera) {
    elements.scannerOverlay.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    scannerWanted = useCamera;
    if (useCamera) {
      await startCamera();
    } else {
      elements.scannerHelp.textContent = "Enter the product barcode below.";
      window.setTimeout(() => elements.barcodeInput.focus(), 50);
    }
  }

  async function closeScanner() {
    scannerWanted = false;
    await stopCamera();
    elements.scannerOverlay.classList.add("hidden");
    document.body.style.overflow = "";
  }

  elements.scanOpen.addEventListener("click", () => openScanner(true));
  elements.manualOpen.addEventListener("click", () => openScanner(false));
  elements.scannerClose.addEventListener("click", closeScanner);
  elements.scannerNext.addEventListener("click", startCamera);

  elements.barcodeForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    await findProduct(elements.barcodeInput.value, false);
  });

  elements.cartList.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-action]");
    const card = event.target.closest("[data-product-id]");
    if (!button || !card) return;
    const id = Number(card.dataset.productId);
    const item = cart.find((product) => product.id === id);
    if (!item) return;
    if (button.dataset.action === "increase") item.quantity = Math.min(9999, item.quantity + 1);
    if (button.dataset.action === "decrease") item.quantity -= 1;
    if (button.dataset.action === "remove" || item.quantity < 1) cart = cart.filter((product) => product.id !== id);
    renderCart();
  });

  elements.cartClear.addEventListener("click", () => {
    if (window.confirm("Clear all products from this sale?")) {
      cart = [];
      renderCart();
    }
  });

  elements.checkoutOpen.addEventListener("click", () => {
    if (!cart.length) return;
    elements.checkoutTotal.textContent = formatMoney(cartTotal());
    elements.checkoutOverlay.classList.remove("hidden");
    document.body.style.overflow = "hidden";
  });

  elements.checkoutClose.addEventListener("click", () => {
    elements.checkoutOverlay.classList.add("hidden");
    document.body.style.overflow = "";
  });

  elements.saveSale.addEventListener("click", async () => {
    if (!cart.length || elements.saveSale.disabled) return;
    elements.saveSale.disabled = true;
    elements.saveSale.textContent = "SAVING…";
    try {
      const response = await fetch(app.dataset.saleUrl, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "X-CSRF-Token": app.dataset.csrf,
        },
        body: JSON.stringify({
          items: cart.map((item) => ({ id: item.id, quantity: item.quantity })),
          customer_name: elements.customerName.value.trim(),
          customer_contact: elements.customerContact.value.trim(),
          customer_address: elements.customerAddress.value.trim(),
        }),
      });
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.message || "Sale could not be saved.");
      cart = [];
      renderCart();
      elements.checkoutOverlay.classList.add("hidden");
      elements.successReference.textContent = `Draft Sale #${data.sale_id} · ${formatMoney(data.total)}`;
      elements.success.classList.remove("hidden");
      document.body.style.overflow = "hidden";
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Sale could not be saved.", true);
    } finally {
      elements.saveSale.disabled = false;
      elements.saveSale.textContent = "SAVE AS DRAFT SALE";
    }
  });

  elements.newSale.addEventListener("click", () => {
    elements.success.classList.add("hidden");
    elements.customerName.value = "";
    elements.customerContact.value = "";
    elements.customerAddress.value = "";
    document.body.style.overflow = "";
    openScanner(true);
  });

  elements.scannerOverlay.addEventListener("click", (event) => {
    if (event.target === elements.scannerOverlay) closeScanner();
  });
  elements.checkoutOverlay.addEventListener("click", (event) => {
    if (event.target === elements.checkoutOverlay) elements.checkoutClose.click();
  });

  window.addEventListener("offline", () => showToast("Connection lost. Your cart is safe on this device.", true));
  window.addEventListener("online", () => showToast("Connection restored."));
  document.addEventListener("visibilitychange", () => {
    if (document.hidden && scannerRunning) stopCamera();
  });

  renderCart();
})();
