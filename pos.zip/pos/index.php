<?php
declare(strict_types=1);

require __DIR__ . '/app/bootstrap.php';

$page = (string) ($_GET['page'] ?? (current_user() ? (current_user()['role'] === 'admin' ? 'admin-dashboard' : 'sale') : 'login'));
$publicPages = ['login'];

if ($page === 'logout') {
    require_login();
    if (!is_post()) {
        http_response_code(405);
        exit('Method not allowed.');
    }
    
    logout_user();
    header('Location: index.php?page=login');
    exit;
}

if ($page === 'login') {
    if (current_user()) {
        redirect(current_user()['role'] === 'admin' ? 'admin-dashboard' : 'sale');
    }
    $loginError = '';
    if (is_post()) {
        try {
            if (login_user((string) ($_POST['username'] ?? ''), (string) ($_POST['password'] ?? ''))) {
                $user = current_user();
                redirect($user['role'] === 'admin' ? 'admin-dashboard' : 'sale');
            }
            usleep(250000);
            $loginError = 'Username or password is incorrect.';
        } catch (RuntimeException $exception) {
            $loginError = $exception->getMessage();
        } catch (Throwable $exception) {
            error_log('Login failed: ' . $exception->getMessage());
            $loginError = 'Unable to sign in right now. Please try again.';
        }
    }
    render_login($loginError);
    exit;
}

$user = require_login();

if ($user['role'] === 'admin') {
    handle_admin_actions($page);
    $allowed = ['admin-dashboard', 'products', 'product-form', 'admin-sales', 'staff', 'staff-form', 'sale-detail'];
    if (!in_array($page, $allowed, true)) {
        redirect('admin-dashboard');
    }
} else {
    $allowed = ['sale', 'my-sales', 'summary', 'sale-detail'];
    if (!in_array($page, $allowed, true)) {
        redirect('sale');
    }
}

switch ($page) {
    case 'sale':
        render_sale_page($user);
        break;
    case 'my-sales':
        render_my_sales($user);
        break;
    case 'summary':
        render_staff_summary($user);
        break;
    case 'sale-detail':
        render_sale_detail($user);
        break;
    case 'admin-dashboard':
        render_admin_dashboard($user);
        break;
    case 'products':
        render_products($user);
        break;
    case 'product-form':
        render_product_form($user);
        break;
    case 'admin-sales':
        render_admin_sales($user);
        break;
    case 'staff':
        render_staff($user);
        break;
    case 'staff-form':
        render_staff_form($user);
        break;
}

function handle_admin_actions(string $page): void
{
    $actions = ['product-save', 'product-status', 'product-delete', 'staff-save', 'staff-status'];
    if (!in_array($page, $actions, true)) {
        return;
    }
    require_role('admin');
    if (!is_post()) {
        http_response_code(405);
        exit('Method not allowed.');
    }

    try {
        verify_csrf();
        if ($page === 'product-save') {
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT) ?: null;
            $name = trim((string) ($_POST['product_name'] ?? ''));
            $barcode = trim((string) ($_POST['barcode'] ?? ''));
            $rate = filter_var($_POST['rate'] ?? null, FILTER_VALIDATE_FLOAT);
            $status = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
            if ($name === '' || strlen($name) > 180 || $barcode === '' || strlen($barcode) > 80 || $rate === false || $rate <= 0 || $rate > 99999999) {
                throw new RuntimeException('Enter a valid product name, barcode, and sale rate.');
            }
            if ($id) {
                $statement = database()->prepare(
                    'UPDATE products SET product_name=:name, barcode=:barcode, rate=:rate, status=:status WHERE id=:id'
                );
                $statement->execute(['name' => $name, 'barcode' => $barcode, 'rate' => $rate, 'status' => $status, 'id' => $id]);
            } else {
                $statement = database()->prepare(
                    'INSERT INTO products (product_name, barcode, rate, status) VALUES (:name, :barcode, :rate, :status)'
                );
                $statement->execute(['name' => $name, 'barcode' => $barcode, 'rate' => $rate, 'status' => $status]);
            }
            set_flash('success', $id ? 'Product updated.' : 'Product added.');
            redirect('products');
        }

        if ($page === 'product-status') {
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
            $status = ($_POST['status'] ?? '') === 'active' ? 'active' : 'inactive';
            $statement = database()->prepare('UPDATE products SET status=:status WHERE id=:id');
            $statement->execute(['status' => $status, 'id' => $id]);
            set_flash('success', $status === 'active' ? 'Product activated.' : 'Product deactivated.');
            redirect('products');
        }

        if ($page === 'product-delete') {
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
            $statement = database()->prepare('DELETE FROM products WHERE id=:id');
            $statement->execute(['id' => $id]);
            set_flash('success', 'Product deleted. Historical sale item details were preserved.');
            redirect('products');
        }

        if ($page === 'staff-save') {
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT) ?: null;
            $name = trim((string) ($_POST['name'] ?? ''));
            $username = trim((string) ($_POST['username'] ?? ''));
            $password = (string) ($_POST['password'] ?? '');
            $status = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
            if ($name === '' || strlen($name) > 120 || $username === '' || strlen($username) > 100 || (!$id && strlen($password) < 8) || ($password !== '' && strlen($password) < 8)) {
                throw new RuntimeException('Enter a name, username/mobile, and a password of at least 8 characters.');
            }
            if ($id) {
                $sql = 'UPDATE users SET name=:name, username=:username, status=:status';
                $params = ['name' => $name, 'username' => $username, 'status' => $status, 'id' => $id];
                if ($password !== '') {
                    $sql .= ', password=:password';
                    $params['password'] = password_hash($password, PASSWORD_DEFAULT);
                }
                $sql .= " WHERE id=:id AND role='staff'";
                database()->prepare($sql)->execute($params);
            } else {
                $statement = database()->prepare(
                    "INSERT INTO users (name, username, password, role, status) VALUES (:name, :username, :password, 'staff', :status)"
                );
                $statement->execute([
                    'name' => $name,
                    'username' => $username,
                    'password' => password_hash($password, PASSWORD_DEFAULT),
                    'status' => $status,
                ]);
            }
            set_flash('success', $id ? 'Staff account updated.' : 'Staff account created.');
            redirect('staff');
        }

        if ($page === 'staff-status') {
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
            $status = ($_POST['status'] ?? '') === 'active' ? 'active' : 'inactive';
            $statement = database()->prepare("UPDATE users SET status=:status WHERE id=:id AND role='staff'");
            $statement->execute(['status' => $status, 'id' => $id]);
            set_flash('success', $status === 'active' ? 'Staff account activated.' : 'Staff account deactivated.');
            redirect('staff');
        }
    } catch (PDOException $exception) {
        if ((string) $exception->getCode() === '23000') {
            set_flash('error', 'That barcode or username/mobile already exists.');
        } else {
            error_log($exception->getMessage());
            set_flash('error', 'The record could not be saved.');
        }
    } catch (Throwable $exception) {
        set_flash('error', $exception->getMessage());
    }

    redirect(str_starts_with($page, 'product') ? 'products' : 'staff');
}

function render_login(string $error): void
{
    $expired = isset($_GET['expired']);
    ?><!doctype html>
    <html lang="en"><head>
        <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
        <meta name="theme-color" content="#0b7656"><meta name="apple-mobile-web-app-capable" content="yes">
        <title><?= e(app_name()) ?> — Login</title>
        <link rel="manifest" href="manifest.json"><link rel="apple-touch-icon" href="icons/icon-192.png">
        <link rel="stylesheet" href="assets/app.css">
    </head><body class="login-body">
    <main class="login-page">
        <div class="brand-mark" aria-hidden="true"><span>|||||</span></div>
        <p class="eyebrow">FAST SALES RECORDING</p>
        <h1><?= e(app_name()) ?></h1>
        <p class="muted center">Sign in and start recording sales.</p>
        <?php if ($error || $expired): ?><div class="alert error"><?= e($error ?: 'Your session expired. Please sign in again.') ?></div><?php endif; ?>
        <form method="post" class="form-card login-form" autocomplete="on">
            <?= csrf_field() ?>
            <label>Username / Mobile<input name="username" autocomplete="username" required autofocus placeholder="Enter username or mobile"></label>
            <label>Password<input type="password" name="password" autocomplete="current-password" required placeholder="Enter password"></label>
            <button class="button primary full" type="submit">LOGIN</button>
        </form>
        <p class="secure-note">Secure staff access</p>
    </main><script src="assets/app.js" defer></script></body></html><?php
}

function layout_start(string $title, array $user, string $page, string $class = ''): void
{
    $flash = pull_flash();
    ?><!doctype html>
    <html lang="en"><head>
        <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover">
        <meta name="theme-color" content="#0b7656"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default">
        <title><?= e($title) ?> — <?= e(app_name()) ?></title>
        <link rel="manifest" href="manifest.json"><link rel="apple-touch-icon" href="icons/icon-192.png"><link rel="stylesheet" href="assets/app.css">
    </head><body class="<?= e($class) ?>" data-page="<?= e($page) ?>">
    <main class="page-shell <?= $user['role'] === 'admin' ? 'admin-shell' : 'staff-shell' ?>">
    <?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>" role="status"><?= e($flash['message']) ?></div><?php endif;
}

function layout_end(array $user, string $page, bool $scanner = false): void
{
    ?></main><?= bottom_navigation($user, $page) ?>
    <?php if ($scanner): ?><script src="vendor/html5-qrcode.min.js" defer></script><?php endif; ?>
    <script src="assets/app.js" defer></script></body></html><?php
}

function bottom_navigation(array $user, string $page): string
{
    $items = $user['role'] === 'admin'
        ? [
            ['admin-dashboard', '⌂', 'Dashboard'], ['products', '▦', 'Products'],
            ['admin-sales', '▤', 'Sales'], ['staff', '♙', 'Staff'],
        ]
        : [
            ['sale', '＋', 'Sale'], ['my-sales', '▤', 'My Sales'], ['summary', '↗', 'Summary'],
        ];
    ob_start(); ?>
    <nav class="bottom-nav" aria-label="Main navigation">
        <?php foreach ($items as [$route, $icon, $label]): ?>
            <a href="index.php?page=<?= e($route) ?>" class="<?= $page === $route ? 'active' : '' ?>"><span><?= $icon ?></span><?= e($label) ?></a>
        <?php endforeach; ?>
        <form method="post" action="index.php?page=logout">
            <?= csrf_field() ?><button type="submit"><span>↪</span>Logout</button>
        </form>
    </nav><?php
    return (string) ob_get_clean();
}

function page_heading(string $eyebrow, string $title, array $user, string $back = ''): void
{
    ?><header class="page-heading">
        <div class="heading-left">
            <?php if ($back): ?><a class="back-button" href="<?= e($back) ?>" aria-label="Go back">‹</a><?php endif; ?>
            <div><p class="eyebrow"><?= e($eyebrow) ?></p><h1><?= e($title) ?></h1></div>
        </div>
        <span class="avatar"><?= e(initials($user['name'])) ?></span>
    </header><?php
}

function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name)) ?: [];
    $letters = '';
    foreach (array_slice($parts, 0, 2) as $part) {
        $letters .= strtoupper(substr($part, 0, 1));
    }
    return $letters ?: 'U';
}

function scalar(string $sql, array $params = []): float
{
    $statement = database()->prepare($sql);
    $statement->execute($params);
    return (float) ($statement->fetchColumn() ?: 0);
}

function friendly_date(string $date): string
{
    return (new DateTimeImmutable($date))->format('d M Y');
}

function render_sale_page(array $user): void
{
    layout_start('New Sale', $user, 'sale', 'sale-page');
    ?><section id="sale-app" data-staff-id="<?= (int) $user['id'] ?>" data-product-url="api/product.php" data-sale-url="api/sales.php" data-csrf="<?= e(csrf_token()) ?>">
        <?php page_heading('SALES STAFF', 'New Sale', $user); ?>
        <section class="scan-hero">
            <button class="scan-button" id="scan-open" type="button"><span class="barcode-symbol">▥</span><b>SCAN BARCODE</b><small>Point camera at product label</small></button>
            <button class="link-button" id="manual-open" type="button">Enter barcode manually</button>
        </section>
        <section class="cart-section" aria-labelledby="cart-title">
            <div class="section-heading"><div><p class="eyebrow muted-label">CURRENT CART</p><h2 id="cart-title">No products yet</h2></div><button class="danger-link hidden" id="cart-clear" type="button">Clear</button></div>
            <div id="cart-list"><div class="empty-card"><span class="barcode-symbol">▥</span><p>Scan a product to start the sale.</p></div></div>
        </section>
        <div class="sale-dock">
            <div class="total-row"><span>TOTAL SALE</span><strong id="sale-total">Rs. 0</strong></div>
            <button class="button primary full" id="checkout-open" type="button" disabled>PROCEED TO CHECKOUT</button>
        </div>

        <div class="overlay hidden" id="scanner-overlay" role="dialog" aria-modal="true" aria-labelledby="scanner-title">
            <section class="sheet scanner-sheet"><div class="sheet-handle"></div>
                <div class="sheet-heading"><div><p class="eyebrow">ADD PRODUCT</p><h2 id="scanner-title">Scan barcode</h2></div><button class="close-button" id="scanner-close" type="button" aria-label="Close scanner">×</button></div>
                <div id="reader" class="camera-reader"></div>
                <p class="scanner-help" id="scanner-help">Allow camera access, then point at a product barcode.</p>
                <div class="divider"><span>or enter barcode</span></div>
                <form id="manual-barcode-form" class="manual-form"><input id="barcode-input" inputmode="numeric" autocomplete="off" maxlength="80" placeholder="Barcode number" aria-label="Barcode number"><button class="button primary" type="submit">ADD</button></form>
                <button class="button secondary full scanner-next hidden" id="scanner-next" type="button">SCAN NEXT PRODUCT</button>
            </section>
        </div>

        <div class="overlay hidden" id="checkout-overlay" role="dialog" aria-modal="true" aria-labelledby="checkout-title">
            <section class="sheet checkout-sheet"><div class="sheet-handle"></div>
                <div class="sheet-heading"><div><p class="eyebrow">CHECKOUT</p><h2 id="checkout-title">Customer details</h2></div><button class="close-button" id="checkout-close" type="button" aria-label="Close checkout">×</button></div>
                <p class="muted small">All customer fields are optional.</p>
                <label>Customer Name <span>Optional</span><input id="customer-name" autocomplete="name" maxlength="150" placeholder="Enter customer name"></label>
                <label>Contact Number <span>Optional</span><input id="customer-contact" inputmode="tel" autocomplete="tel" maxlength="60" placeholder="03XX XXXXXXX"></label>
                <label>Address <span>Optional</span><textarea id="customer-address" rows="2" maxlength="500" placeholder="Enter address"></textarea></label>
                <div class="checkout-total"><span>Total sale</span><strong id="checkout-total">Rs. 0</strong></div>
                <button class="button primary full" id="save-sale" type="button">SAVE AS DRAFT SALE</button>
            </section>
        </div>

        <div class="success-screen hidden" id="sale-success" role="dialog" aria-modal="true">
            <div class="success-mark">✓</div><p class="eyebrow">DRAFT SALE</p><h1>Sale Saved Successfully</h1><p class="muted center" id="success-reference"></p>
            <button class="button primary full" id="new-sale" type="button">NEW SALE</button>
        </div>
        <div class="toast hidden" id="toast" role="status"></div>
    </section><?php
    layout_end($user, 'sale', true);
}

function render_my_sales(array $user): void
{
    layout_start('My Sales', $user, 'my-sales');
    page_heading('SALES STAFF', 'My Sales', $user);
    $statement = database()->prepare('SELECT id, sale_date, sale_time, customer_name, total_amount, status FROM sales WHERE staff_id=:staff_id ORDER BY id DESC LIMIT 100');
    $statement->execute(['staff_id' => $user['id']]);
    $sales = $statement->fetchAll();
    ?><div class="section-heading padded-top"><div><p class="eyebrow muted-label">RECORDED SALES</p><h2><?= count($sales) ?> recent sale<?= count($sales) === 1 ? '' : 's' ?></h2></div></div>
    <section class="record-list">
        <?php if (!$sales): ?><div class="empty-card"><p>No sales recorded yet.</p><a class="button primary" href="index.php?page=sale">NEW SALE</a></div><?php endif; ?>
        <?php foreach ($sales as $sale): ?><a class="record-card" href="index.php?page=sale-detail&id=<?= (int) $sale['id'] ?>">
            <div><span class="status-badge">DRAFT</span><h3>Sale #<?= (int) $sale['id'] ?></h3><p><?= e(friendly_date($sale['sale_date'])) ?> · <?= e(date('h:i A', strtotime($sale['sale_time']))) ?></p></div>
            <div class="record-amount"><strong><?= e(money($sale['total_amount'])) ?></strong><span><?= e($sale['customer_name'] ?: 'Walk-in customer') ?> ›</span></div>
        </a><?php endforeach; ?>
    </section><?php
    layout_end($user, 'my-sales');
}

function render_staff_summary(array $user): void
{
    $today = (new DateTimeImmutable())->format('Y-m-d');
    $month = (new DateTimeImmutable('first day of this month'))->format('Y-m-d');
    $params = ['id' => $user['id']];
    $todayTotal = scalar('SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE staff_id=:id AND sale_date=:today', $params + ['today' => $today]);
    $monthTotal = scalar('SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE staff_id=:id AND sale_date>=:month', $params + ['month' => $month]);
    $allTotal = scalar('SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE staff_id=:id', $params);
    $count = scalar('SELECT COUNT(*) FROM sales WHERE staff_id=:id', $params);
    $recent = database()->prepare('SELECT id, sale_date, customer_name, total_amount FROM sales WHERE staff_id=:id ORDER BY id DESC LIMIT 8');
    $recent->execute($params);
    layout_start('Summary', $user, 'summary');
    page_heading('MY PERFORMANCE', 'Sales Summary', $user);
    ?><section class="metric-grid staff-metrics">
        <?= metric_card("Today's Sale", money($todayTotal), 'green') ?>
        <?= metric_card('This Month', money($monthTotal), 'blue') ?>
        <?= metric_card('Total Sale', money($allTotal), 'dark') ?>
        <?= metric_card('Number of Sales', number_format($count), 'sand') ?>
    </section>
    <div class="section-heading padded-top"><div><p class="eyebrow muted-label">RECENT ACTIVITY</p><h2>Latest sales</h2></div><a class="link-button" href="index.php?page=my-sales">View all</a></div>
    <section class="compact-list">
        <?php foreach ($recent->fetchAll() as $sale): ?><a href="index.php?page=sale-detail&id=<?= (int) $sale['id'] ?>"><div><b>#<?= (int) $sale['id'] ?></b><span><?= e(friendly_date($sale['sale_date'])) ?> · <?= e($sale['customer_name'] ?: 'Walk-in') ?></span></div><strong><?= e(money($sale['total_amount'])) ?> ›</strong></a><?php endforeach; ?>
    </section><?php
    layout_end($user, 'summary');
}

function render_sale_detail(array $user): void
{
    $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
    $sql = 'SELECT * FROM sales WHERE id=:id';
    $params = ['id' => $id];
    if ($user['role'] === 'staff') {
        $sql .= ' AND staff_id=:staff_id';
        $params['staff_id'] = $user['id'];
    }
    $statement = database()->prepare($sql . ' LIMIT 1');
    $statement->execute($params);
    $sale = $statement->fetch();
    if (!$sale) {
        http_response_code(404);
        set_flash('error', 'Sale not found.');
        redirect($user['role'] === 'admin' ? 'admin-sales' : 'my-sales');
    }
    $items = database()->prepare('SELECT * FROM sale_items WHERE sale_id=:id ORDER BY id');
    $items->execute(['id' => $id]);
    $back = $user['role'] === 'admin' ? 'index.php?page=admin-sales' : 'index.php?page=my-sales';
    layout_start('Sale #' . $id, $user, 'sale-detail');
    page_heading('DRAFT SALE', 'Sale #' . $id, $user, $back);
    ?><section class="detail-summary">
        <div><span>Date & Time</span><strong><?= e(friendly_date($sale['sale_date'])) ?> · <?= e(date('h:i A', strtotime($sale['sale_time']))) ?></strong></div>
        <div><span>Sales Staff</span><strong><?= e($sale['staff_name']) ?></strong></div>
        <div class="detail-total"><span>Total Sale</span><strong><?= e(money($sale['total_amount'])) ?></strong></div>
    </section>
    <div class="section-heading padded-top"><div><p class="eyebrow muted-label">PRODUCTS</p><h2>Sale items</h2></div></div>
    <section class="item-list">
        <?php foreach ($items->fetchAll() as $item): ?><article><div><h3><?= e($item['product_name']) ?></h3><p><?= e($item['barcode']) ?> · <?= e(money($item['rate'])) ?> × <?= (int) $item['quantity'] ?></p></div><strong><?= e(money($item['line_total'])) ?></strong></article><?php endforeach; ?>
    </section>
    <div class="section-heading padded-top"><div><p class="eyebrow muted-label">CUSTOMER</p><h2>Customer details</h2></div></div>
    <section class="customer-card">
        <div><span>Name</span><strong><?= e($sale['customer_name'] ?: 'Not entered') ?></strong></div>
        <div><span>Contact</span><strong><?= e($sale['customer_contact'] ?: 'Not entered') ?></strong></div>
        <div><span>Address</span><strong><?= nl2br(e($sale['customer_address'] ?: 'Not entered')) ?></strong></div>
    </section><?php
    layout_end($user, 'sale-detail');
}

function metric_card(string $label, string $value, string $tone): string
{
    return '<article class="metric-card ' . e($tone) . '"><span>' . e($label) . '</span><strong>' . e($value) . '</strong></article>';
}

function render_admin_dashboard(array $user): void
{
    $today = (new DateTimeImmutable())->format('Y-m-d');
    $month = (new DateTimeImmutable('first day of this month'))->format('Y-m-d');
    $todayTotal = scalar('SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE sale_date=:date', ['date' => $today]);
    $monthTotal = scalar('SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE sale_date>=:date', ['date' => $month]);
    $allTotal = scalar('SELECT COALESCE(SUM(total_amount),0) FROM sales');
    $staffCount = scalar("SELECT COUNT(*) FROM users WHERE role='staff' AND status='active'");
    $staff = database()->prepare(
        "SELECT u.id,u.name,u.status,
        COALESCE(SUM(CASE WHEN s.sale_date=:today THEN s.total_amount ELSE 0 END),0) today_total,
        COALESCE(SUM(CASE WHEN s.sale_date>=:month THEN s.total_amount ELSE 0 END),0) month_total,
        COALESCE(SUM(s.total_amount),0) total_amount
        FROM users u LEFT JOIN sales s ON s.staff_id=u.id WHERE u.role='staff' GROUP BY u.id,u.name,u.status ORDER BY total_amount DESC,u.name"
    );
    $staff->execute(['today' => $today, 'month' => $month]);
    layout_start('Dashboard', $user, 'admin-dashboard');
    page_heading('ADMIN', 'Sales Dashboard', $user);
    ?><section class="metric-grid admin-metrics">
        <?= metric_card("Today's Total", money($todayTotal), 'green') ?>
        <?= metric_card('This Month', money($monthTotal), 'blue') ?>
        <?= metric_card('All Recorded Sales', money($allTotal), 'dark') ?>
        <?= metric_card('Active Sales Staff', number_format($staffCount), 'sand') ?>
    </section>
    <div class="section-heading padded-top"><div><p class="eyebrow muted-label">BY SALES STAFF</p><h2>Staff performance</h2></div></div>
    <section class="staff-performance">
        <?php foreach ($staff->fetchAll() as $row): ?><a href="index.php?page=admin-sales&staff_id=<?= (int) $row['id'] ?>&preset=month" class="performance-card">
            <div class="performance-head"><span class="avatar small-avatar"><?= e(initials($row['name'])) ?></span><div><h3><?= e($row['name']) ?></h3><p><?= e(ucfirst($row['status'])) ?> · Tap for sales</p></div><b>›</b></div>
            <div class="performance-values"><div><span>Today</span><strong><?= e(money($row['today_total'])) ?></strong></div><div><span>Month</span><strong><?= e(money($row['month_total'])) ?></strong></div><div><span>Total</span><strong><?= e(money($row['total_amount'])) ?></strong></div></div>
        </a><?php endforeach; ?>
    </section><?php
    layout_end($user, 'admin-dashboard');
}

function render_products(array $user): void
{
    $q = trim((string) ($_GET['q'] ?? ''));
    $sql = 'SELECT * FROM products';
    $params = [];
    if ($q !== '') {
        $sql .= ' WHERE product_name LIKE :q OR barcode LIKE :q';
        $params['q'] = '%' . $q . '%';
    }
    $sql .= " ORDER BY status='active' DESC, product_name LIMIT 500";
    $statement = database()->prepare($sql);
    $statement->execute($params);
    $products = $statement->fetchAll();
    layout_start('Products', $user, 'products');
    page_heading('ADMIN', 'Products', $user);
    ?><div class="action-row"><form class="search-form" method="get"><input type="hidden" name="page" value="products"><input name="q" value="<?= e($q) ?>" placeholder="Search name or barcode"><button class="button secondary" type="submit">SEARCH</button></form><a class="button primary" href="index.php?page=product-form">+ ADD</a></div>
    <p class="list-count"><?= count($products) ?> product<?= count($products) === 1 ? '' : 's' ?></p>
    <section class="product-list">
        <?php foreach ($products as $product): ?><article class="management-card <?= $product['status'] === 'inactive' ? 'inactive' : '' ?>">
            <div class="management-main"><div><span class="status-badge <?= e($product['status']) ?>"><?= e(strtoupper($product['status'])) ?></span><h3><?= e($product['product_name']) ?></h3><p>Barcode: <?= e($product['barcode']) ?></p></div><strong><?= e(money($product['rate'])) ?></strong></div>
            <div class="card-actions"><a href="index.php?page=product-form&id=<?= (int) $product['id'] ?>">Edit</a>
                <form method="post" action="index.php?page=product-status"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $product['id'] ?>"><input type="hidden" name="status" value="<?= $product['status'] === 'active' ? 'inactive' : 'active' ?>"><button type="submit"><?= $product['status'] === 'active' ? 'Deactivate' : 'Activate' ?></button></form>
                <form method="post" action="index.php?page=product-delete" onsubmit="return confirm('Delete this product? Historical sale details will remain.')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $product['id'] ?>"><button class="danger" type="submit">Delete</button></form>
            </div>
        </article><?php endforeach; ?>
    </section><?php
    layout_end($user, 'products');
}

function render_product_form(array $user): void
{
    $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
    $product = ['id' => '', 'product_name' => '', 'barcode' => '', 'rate' => '', 'status' => 'active'];
    if ($id) {
        $statement = database()->prepare('SELECT * FROM products WHERE id=:id');
        $statement->execute(['id' => $id]);
        $product = $statement->fetch() ?: $product;
    }
    layout_start($id ? 'Edit Product' : 'Add Product', $user, 'products');
    page_heading('PRODUCT MASTER', $id ? 'Edit Product' : 'Add Product', $user, 'index.php?page=products');
    ?><form class="form-card management-form" method="post" action="index.php?page=product-save">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= e((string) $product['id']) ?>">
        <label>Product Name<input name="product_name" maxlength="180" required value="<?= e($product['product_name']) ?>" placeholder="e.g. Bath Towel White"></label>
        <label>Barcode Number<input name="barcode" maxlength="80" inputmode="numeric" required value="<?= e($product['barcode']) ?>" placeholder="Scan or enter barcode"></label>
        <label>Sale Rate (Rs.)<input name="rate" type="number" inputmode="decimal" min="0.01" max="99999999" step="0.01" required value="<?= e((string) $product['rate']) ?>" placeholder="850"></label>
        <label>Status<select name="status"><option value="active" <?= $product['status'] === 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= $product['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option></select></label>
        <button class="button primary full" type="submit">SAVE PRODUCT</button>
    </form><?php
    layout_end($user, 'products');
}

function report_dates(string $preset): array
{
    $today = new DateTimeImmutable('today');
    return match ($preset) {
        'yesterday' => [$today->modify('-1 day'), $today->modify('-1 day')],
        'week' => [$today->modify('monday this week'), $today],
        'month' => [$today->modify('first day of this month'), $today],
        'custom' => valid_custom_dates($today),
        default => [$today, $today],
    };
}

function valid_custom_dates(DateTimeImmutable $fallback): array
{
    $fromText = (string) ($_GET['from'] ?? '');
    $toText = (string) ($_GET['to'] ?? '');
    $from = DateTimeImmutable::createFromFormat('!Y-m-d', $fromText);
    $to = DateTimeImmutable::createFromFormat('!Y-m-d', $toText);
    if (!$from || !$to || $from->format('Y-m-d') !== $fromText || $to->format('Y-m-d') !== $toText || $from > $to) {
        return [$fallback, $fallback];
    }
    return [$from, $to];
}

function render_admin_sales(array $user): void
{
    $preset = in_array($_GET['preset'] ?? 'today', ['today', 'yesterday', 'week', 'month', 'custom'], true) ? (string) $_GET['preset'] : 'today';
    [$from, $to] = report_dates($preset);
    $staffId = filter_var($_GET['staff_id'] ?? null, FILTER_VALIDATE_INT) ?: 0;
    $where = 'sale_date BETWEEN :from AND :to';
    $params = ['from' => $from->format('Y-m-d'), 'to' => $to->format('Y-m-d')];
    if ($staffId) {
        $where .= ' AND staff_id=:staff_id';
        $params['staff_id'] = $staffId;
    }
    $summary = database()->prepare("SELECT staff_id, staff_name, COUNT(*) sale_count, SUM(total_amount) total_amount FROM sales WHERE {$where} GROUP BY staff_id,staff_name ORDER BY total_amount DESC");
    $summary->execute($params);
    $sales = database()->prepare("SELECT id,staff_name,customer_name,sale_date,sale_time,total_amount FROM sales WHERE {$where} ORDER BY sale_date DESC,sale_time DESC,id DESC LIMIT 500");
    $sales->execute($params);
    $staff = database()->query("SELECT id,name FROM users WHERE role='staff' ORDER BY name")->fetchAll();
    $reportTotal = scalar("SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE {$where}", $params);
    $reportCount = scalar("SELECT COUNT(*) FROM sales WHERE {$where}", $params);
    layout_start('Sales Report', $user, 'admin-sales');
    page_heading('ADMIN', 'Sales Report', $user);
    ?><div class="preset-tabs">
        <?php foreach (['today'=>'Today','yesterday'=>'Yesterday','week'=>'This Week','month'=>'This Month','custom'=>'Custom'] as $key=>$label): ?><a class="<?= $preset === $key ? 'active' : '' ?>" href="index.php?page=admin-sales&preset=<?= e($key) ?><?= $staffId ? '&staff_id=' . $staffId : '' ?>"><?= e($label) ?></a><?php endforeach; ?>
    </div>
    <form class="report-filter form-card" method="get"><input type="hidden" name="page" value="admin-sales"><input type="hidden" name="preset" value="custom">
        <label>From<input type="date" name="from" value="<?= e($from->format('Y-m-d')) ?>"></label><label>To<input type="date" name="to" value="<?= e($to->format('Y-m-d')) ?>"></label>
        <label>Sales Staff<select name="staff_id"><option value="">All staff</option><?php foreach ($staff as $member): ?><option value="<?= (int) $member['id'] ?>" <?= $staffId === (int) $member['id'] ? 'selected' : '' ?>><?= e($member['name']) ?></option><?php endforeach; ?></select></label>
        <button class="button primary" type="submit">APPLY</button>
    </form>
    <section class="report-total"><div><span><?= e(friendly_date($from->format('Y-m-d'))) ?><?= $from != $to ? ' — ' . e(friendly_date($to->format('Y-m-d'))) : '' ?></span><strong><?= number_format($reportCount) ?> sales</strong></div><b><?= e(money($reportTotal)) ?></b></section>
    <div class="section-heading padded-top"><div><p class="eyebrow muted-label">STAFF SUMMARY</p><h2>Performance</h2></div></div>
    <section class="summary-list"><?php foreach ($summary->fetchAll() as $row): ?><article><div><h3><?= e($row['staff_name']) ?></h3><p><?= (int) $row['sale_count'] ?> sale<?= (int) $row['sale_count'] === 1 ? '' : 's' ?></p></div><strong><?= e(money($row['total_amount'])) ?></strong></article><?php endforeach; ?></section>
    <div class="section-heading padded-top"><div><p class="eyebrow muted-label">TRANSACTIONS</p><h2>Sale details</h2></div></div>
    <section class="record-list"><?php foreach ($sales->fetchAll() as $sale): ?><a class="record-card" href="index.php?page=sale-detail&id=<?= (int) $sale['id'] ?>"><div><span class="status-badge">DRAFT</span><h3>#<?= (int) $sale['id'] ?> · <?= e($sale['staff_name']) ?></h3><p><?= e(friendly_date($sale['sale_date'])) ?> · <?= e($sale['customer_name'] ?: 'Walk-in') ?></p></div><div class="record-amount"><strong><?= e(money($sale['total_amount'])) ?></strong><span>Open ›</span></div></a><?php endforeach; ?></section><?php
    layout_end($user, 'admin-sales');
}

function render_staff(array $user): void
{
    $staff = database()->query("SELECT id,name,username,status,created_at FROM users WHERE role='staff' ORDER BY status='active' DESC,name")->fetchAll();
    layout_start('Staff', $user, 'staff');
    page_heading('ADMIN', 'Sales Staff', $user);
    ?><div class="action-row single-action"><p class="list-count"><?= count($staff) ?> staff account<?= count($staff) === 1 ? '' : 's' ?></p><a class="button primary" href="index.php?page=staff-form">+ ADD STAFF</a></div>
    <section class="staff-list">
        <?php foreach ($staff as $member): ?><article class="management-card <?= $member['status'] === 'inactive' ? 'inactive' : '' ?>">
            <div class="staff-card-head"><span class="avatar"><?= e(initials($member['name'])) ?></span><div><span class="status-badge <?= e($member['status']) ?>"><?= e(strtoupper($member['status'])) ?></span><h3><?= e($member['name']) ?></h3><p><?= e($member['username']) ?></p></div></div>
            <div class="card-actions"><a href="index.php?page=admin-sales&staff_id=<?= (int) $member['id'] ?>&preset=month">View Sales</a><a href="index.php?page=staff-form&id=<?= (int) $member['id'] ?>">Edit</a>
                <form method="post" action="index.php?page=staff-status"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $member['id'] ?>"><input type="hidden" name="status" value="<?= $member['status'] === 'active' ? 'inactive' : 'active' ?>"><button type="submit"><?= $member['status'] === 'active' ? 'Deactivate' : 'Activate' ?></button></form>
            </div>
        </article><?php endforeach; ?>
    </section><?php
    layout_end($user, 'staff');
}

function render_staff_form(array $user): void
{
    $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
    $member = ['id' => '', 'name' => '', 'username' => '', 'status' => 'active'];
    if ($id) {
        $statement = database()->prepare("SELECT id,name,username,status FROM users WHERE id=:id AND role='staff'");
        $statement->execute(['id' => $id]);
        $member = $statement->fetch() ?: $member;
    }
    layout_start($id ? 'Edit Staff' : 'Add Staff', $user, 'staff');
    page_heading('STAFF ACCOUNT', $id ? 'Edit Staff' : 'Add Sales Staff', $user, 'index.php?page=staff');
    ?><form class="form-card management-form" method="post" action="index.php?page=staff-save">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= e((string) $member['id']) ?>">
        <label>Staff Name<input name="name" maxlength="120" required value="<?= e($member['name']) ?>" placeholder="Full name"></label>
        <label>Username / Mobile<input name="username" maxlength="100" autocomplete="off" required value="<?= e($member['username']) ?>" placeholder="Login username or mobile"></label>
        <label><?= $id ? 'New Password' : 'Password' ?> <?= $id ? '<span>Leave blank to keep current</span>' : '' ?><input type="password" name="password" minlength="8" autocomplete="new-password" <?= $id ? '' : 'required' ?> placeholder="Minimum 8 characters"></label>
        <label>Status<select name="status"><option value="active" <?= $member['status'] === 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= $member['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option></select></label>
        <button class="button primary full" type="submit">SAVE STAFF ACCOUNT</button>
    </form><?php
    layout_end($user, 'staff');
}
